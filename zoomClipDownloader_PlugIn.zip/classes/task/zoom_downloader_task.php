<?php
namespace mod_zoomdownloader\task;

defined('MOODLE_INTERNAL') || die();

use core\task\scheduled_task;

class zoom_downloader_task extends scheduled_task {
    public function get_name() {
        return get_string('taskname', 'mod_zoomdownloader');
    }

    public function execute() {
        global $DB;
        
        // Obtener todas las instancias activas del módulo
        $instances = $DB->get_records('zoomdownloader', ['enabled' => 1]);
        
        foreach ($instances as $instance) {
            try {
                $course = $DB->get_record('course', ['id' => $instance->course]);
                
                // Obtener enlaces de Zoom
                $zoom_links = ZoomClipDownloader_get_zoom_meeting_links($course->id);
                
                // Configurar el administrador de autenticación
                $authManager = new \AuthManager(
                    get_config('mod_zoomdownloader', 'zoom'),
                    get_config('mod_zoomdownloader', 'google'),
                    $DB
                );
                
                // Obtener tokens
                $zoomToken = $authManager->getZoomAccessToken();
                $googleToken = $authManager->getGoogleAccessToken();
                
                // Descargar grabaciones
                ZoomClipDownloader_download_zoom_recordings($zoom_links, $zoomToken);
                
                // Subir a Google Drive
                ZoomClipDownloader_upload_to_google_drive($googleToken);
                
                mtrace("Procesamiento completado para el curso " . $course->fullname);
            } catch (\Exception $e) {
                mtrace("Error en el curso {$course->fullname}: " . $e->getMessage());
            }
        }
    }
}